package vn.codegym.model;

import org.springframework.stereotype.Component;

/**
 * (C) Copyright 2023 iHub Academy. All Rights Reserved.
 *
 * @author TrungDC
 * @version 1.0
 * @since 12/27/2023
 */
@Component
public class ABC {
}